package com.pos.petra.app.Util;

import com.pos.petra.app.Model.Roles.LoadCashiers;

import java.util.ArrayList;

public class SingleTon {
    public static ArrayList<String> admins=new ArrayList<>();
    public static ArrayList<String> cashiers;
    public static LoadCashiers cashierData;
}
