package com.pos.petra.app.ImageCropper.cropwindow;

import android.graphics.Bitmap;
import android.net.Uri;

/**
 * Created by manisha on 12/12/16.
 */

public class Constants {
    public static Uri IMAGE_URI;
    public static Bitmap CROPPED_BITMAP;
    public static boolean BTN_OK_CLICKED = false;
}
