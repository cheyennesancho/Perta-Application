package com.pos.petra.app;

import android.content.ContentProvider;
import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {}