package com.yagna.petra.app.Product.SubCategory;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yagna.petra.app.Model.Product.Categories;
import com.yagna.petra.app.Model.Product.SubCategories;
import com.yagna.petra.app.Product.Category.CategoryActivity;
import com.yagna.petra.app.R;
import com.yagna.petra.app.Util.CustomDialog;
import com.yagna.petra.app.Util.Utils;

import java.util.ArrayList;

public class SubCategoryReAdapter extends RecyclerView.Adapter<SubCategoryReAdapter.ViewHolder> {
    private final SharedPreferences common_mypref;
    final CustomDialog cd;
    private final Utils util;
    private final ArrayList<SubCategories.SubCategory> arrayData;
    SubCategoryActivity context;
    private static LayoutInflater inflater=null;
    
    public SubCategoryReAdapter(SubCategoryActivity productActivity, ArrayList<SubCategories.SubCategory> arrayData) {
        context=productActivity;
        util=new Utils(context.getApplicationContext());
        this.arrayData=arrayData;
        common_mypref = context.getSharedPreferences(
                "user", 0);
        cd=new CustomDialog(context);
        inflater = (LayoutInflater)context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.b_item_category, parent, false);
        SubCategoryReAdapter.ViewHolder vh = new SubCategoryReAdapter.ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.txt_titlepcode.setTextColor(context.getResources().getColor(R.color.colorAccent));
        holder.p_code.setText(arrayData.get(position).code);
        holder.p_name.setText(arrayData.get(position).title);
        holder.p_description.setText(arrayData.get(position).description);
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.addData(true,position);
            }
        });
        holder.ly_sub_categ.setVisibility(View.VISIBLE);
        holder.ly_categ_view.setVisibility(View.GONE);
        holder.sub_categ_name.setText(arrayData.get(position).title);
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.position=position;
                cd.showAlertmulti(false,"Do you want to delete \""+holder.p_name.getText().toString()+"\" SubCategory?");
                context.subcateg_id =arrayData.get(position).id;
                notifyDataSetChanged();
                if(arrayData.size()==0){
                    context.listview.setVisibility(View.GONE);
                    context.tv_no_record.setVisibility(View.VISIBLE);
                }
                else {
                    context.listview.setVisibility(View.VISIBLE);
                    context.tv_no_record.setVisibility(View.GONE);
                }

            }
        });

    }


    
    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arrayData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView p_name,p_price,p_description,sub_categ_name,p_code,txt_titledescription,txt_titleprice,txt_titlepcode,txt_titlepname;
        ImageView p_img;
        LinearLayout ly_sub_categ, ly_categ_view;

        Button edit,delete;

        public ViewHolder(View rowView) {
            super(rowView);
            p_name = (TextView) rowView.findViewById(R.id.product_name);
            p_description = (TextView) rowView.findViewById(R.id.product_desc);
            edit=(Button) rowView.findViewById(R.id.edit_);
            delete=(Button) rowView.findViewById(R.id.delete_);
            p_code=(TextView) rowView.findViewById(R.id.p_code);
            ly_sub_categ = (LinearLayout) rowView.findViewById(R.id.ly_sub_categ);
            ly_categ_view = (LinearLayout) rowView.findViewById(R.id.ly_categ_view);
            txt_titlepcode=(TextView) rowView.findViewById(R.id.txt_titlecode);
            txt_titlepcode.setText("SubCategory Code:");
            sub_categ_name = (TextView) rowView.findViewById(R.id.sub_categ_name);


        }
    }





}
