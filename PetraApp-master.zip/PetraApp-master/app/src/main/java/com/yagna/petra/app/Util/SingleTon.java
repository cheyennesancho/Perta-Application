package com.yagna.petra.app.Util;

import com.yagna.petra.app.Model.Cashiers;
import com.yagna.petra.app.Model.LoadCashiers;

import org.json.JSONObject;

import java.util.ArrayList;

public class SingleTon {


    public static ArrayList<String> admins=new ArrayList<>();
    public static ArrayList<String> cashiers;
    public static LoadCashiers cashierData;
}
